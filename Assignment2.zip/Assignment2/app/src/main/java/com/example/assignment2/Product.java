package com.example.assignment2;

public class Product {
    Integer id;
    String name;
    Double price;
    Integer quantity;

    public Product(Integer id, String name, Double price, Integer quantity) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.quantity = quantity;
    }
}
